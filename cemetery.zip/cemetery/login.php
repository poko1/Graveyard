<html>
<head>
<header><h1>Employee Login</h1></header> 
</head>
<body> 
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">

       
    <p>
      Employee ID Number:<br />
      <input type="text" name="emp_id" size="30" maxlength="30" value="" />
    </p> 
	<p>
      Password:<br />
      <input type="text" name="password" size="25" maxlength="25" value="" /> 
    </p>
    <p>
      <input type="submit" name="submit" value="Submit!" /> 
    </p>
</form>
<a href="form.php">Back</a>
</body>



</html>