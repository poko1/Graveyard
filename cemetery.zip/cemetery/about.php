<html>

<body>
<header><h1>ABOUT US</h1></header> 

<a href="totaldeceased.php">TOTAL NUMBER OF DECEASED</a>
<br>
<a href="totalgraves.php">TOTAL NUMBER OF GRAVES</a>
<br>
<a href="totalemp.php">TOTAL NUMBER OF EMPLOYEES</a>
<br>
</body>



</html>