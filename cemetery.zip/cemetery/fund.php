<html>

	<head>
		<title>Search</title>
<header><h1>Govt. & Non-Govt Fund Summary</h1></header> 
	</head>
	<body>
	
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle


$conn = oci_connect('maliha', 'poko', 'localhost/xe');

$query = "select donor_type ,sum(amount) ,round(avg(amount)) 
from donor join donates_money using(donor_id) join donated_money using(donation_id)
group by donor_type ";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
	print "<th>DONOR TYPE</th>\n";
        print "<th>TOTAL DOANTED MONEY</th>\n";
	print "<th>AVERAGE AMOUNT</th>\n";
	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);



?>
</html>