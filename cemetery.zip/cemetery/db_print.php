<html>
<body>
<?php
include "db_insert_reg.php";

   // If the submit button has been pressed...

   if (isset($_POST['submit']))
   {

      // Connect to the database
      $c = @oci_connect('maliha', 'poko', 'localhost/xe')
                or die("Could not connect to Oracle server");

$s = "SELECT emp_id,first_name,last_name,joining_date,phone_number
FROM employee,phone_number
where emp_id=phone_number.id
";
$stid = oci_parse($c, $s);

if( !oci_execute($stid) ) {
    $e = oci_error();
    echo htmlentities($e['message'], ENT_QUOTES);
	oci_close($c);
} else {
	// retrieve the results
	print "<table cols=5 border=1>\n";
	print "<tr>\n";
	print "<th>Employee ID</th>\n";
	print "<th>First Name</th>\n";
	print "<th>Last Name</th>\n";
	print "<th>Joining Date</th>\n";
	print "<th>Phone No.</th>\n";
	print "</tr>";
	while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
    	echo "<tr>\n";
    	foreach ($row as $item) {
        	echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
    	}
    	echo "</tr>\n";
	}
	oci_close($c);
	echo "</table>\n";
   }
   }
?>
</body>
</html>