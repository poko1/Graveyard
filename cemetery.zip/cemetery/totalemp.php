<html>

	<head>
		<title>Search</title>
<header><h1>NUMBER OF EMPLOYEES</h1></header> 
	</head>
	<body>
	
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle


$conn = oci_connect('maliha', 'poko', 'localhost/xe');

$query = "SELECT COUNT(emp_id)
from employee";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);


// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
	print "<td> Total </td>\n";

	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
	 
	 
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);



?>
</html>