<?php
$profpic = "cemetery.jpg";
?>
<html>
<span style="display:inline-block; width: YOURWIDTH;"></span>
<style type="text/css">
body {
background-image: url('<?php echo $profpic;?>');
                background-size: auto;
				background-repeat: no-repeat;
				background-position : top center;
                background-color: #ffff ;
                color: #fff;
				text-align: center;
                //font-family: 'Raleway', sans-serif;
                font-weight: 10000;
                height: 100vh;
                margin: auto;
				

}




</style>

<span style="display:inline-block; width: YOURWIDTH;"></span>

<body>
<header><h1>Graveyard Database</h1></header> 
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<a href="emp_corner.php">EMPLOYEE CORNER</a>
style="white-space:pre"
<a href="deceased.php">SEARCH</a>
style="white-space:pre"
<a href="reserve.php">RESERVE</a>
style="white-space:pre"
<a href="donate.php">DONATE</a>
style="white-space:pre"
<a href="about.php">ABOUT US</a>


</body>



</html>