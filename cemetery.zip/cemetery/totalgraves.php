<html>

	<head>
		<title>Search</title>
<header><h1>NUMBER OF GRAVES</h1></header> 
	</head>
	<body>
	
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle


$conn = oci_connect('maliha', 'poko', 'localhost/xe');

$query = "SELECT plot,section,COUNT(grave_no)
from grave 
group by section,plot
order by plot";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);


// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
	print "<td> Plot </td> <td> Section </td> <td> Total</td>\n";

	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
	 
	 
   }
   print '</tr>';
}
print '</table>';


$q = "SELECT COUNT (grave_no) 
from grave";
$s = oci_parse($conn, $q);
$r = oci_execute($s);

print '<table border="1">';
	print "<tr>\n";
	print "<th>Total Graves</th>\n";

	print "</tr>";
while ($row = oci_fetch_array($s, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
	 
	 
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);



?>
</html>