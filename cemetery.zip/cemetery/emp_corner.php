<html>

<body>
<header><h1>EMPLOYEE CORNER</h1></header> 

<a href="db_print.php">REGISTER</a>
<br>
<a href="query.php">SEARCH</a>
<br>
<a href="login.php">LOGIN</a>
<br>
</body>



</html>