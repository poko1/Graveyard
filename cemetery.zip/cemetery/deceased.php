<html>

	<head>
		<title>Search</title>
<header><h1>Deceased Details</h1></header> 
	</head>
	<body>
		<form method="POST" action="">
			<input type="text" name="q" placeholder="query">
			<input type="submit" name="search" value="Search">
		</form>
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle
if(isset($_POST['search'])){

$conn = oci_connect('maliha', 'poko', 'localhost/xe');
$q = $_POST['q'];
$query = "SELECT reg_no,first_name,last_name,floor((date_of_burial-DOB)/365),occupation,city,street,cause_of_death,gender,grave_no,section,plot 
			FROM known_native JOIN buried_in_k USING (reg_no) JOIN grave USING (grave_no) 
			WHERE first_name like '%$q%' or last_name like '%$q%' or reg_no like '%$q%' ";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);


// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
print "<th>Registration No.</th>\n";
	print "<th>First name</th>\n";
        print "<th>Last name</th>\n";
	print "<th>Age</th>\n";
	print "<th>Occupation</th>\n";
	print "<th>City</th>\n";
	print "<th>Street</th>\n";
        print "<th>Cause of death</th>\n";
        print "<th>Gender</th>\n";
         print "<th>Grave No.</th>\n";
		print "<th>Grave section</th>\n";
		print "<th>Grave Plot</th>\n";
	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);
}


?>
</html>