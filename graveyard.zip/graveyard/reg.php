<html>
<head>
<header><h1>Employee Registration</h1></header> 
</head>
<body> 
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">

       
    <p>
      Employee ID Number:(*)<br />
      <input type="text" name="emp_id" size="30" maxlength="30" value="" />
    </p> 
    <p>
      NID no.:(*)<br />
      <input type="text" name="nid" size="30" maxlength="30" value="" />
    </p>
    <p>
      First Name:(*)<br />
      <input type="text" name="first_name" size="40" maxlength="40" value="" /> 
    </p> 
    <p>
      Last Name:<br />
      <input type="text" name="last_name" size="40" maxlength="40" value="" /> 
    </p>  
    <p>
      Job Type:<br />
      <input type="text" name="jobtype" size="25" maxlength="25" value="" /> 
    </p>  
    <p>
      Date Of Joining:(*)<br />
      <input type="date" name="doj" size="20" maxlength="30" value="<?php echo date("Y-m-d");?>" />
    </p> 
    <p>
      Date of Birth:(*)<br />
      <input type="date" name="dob" size="25" maxlength="30" value="<?php echo date("Y-m-d");?>" /> 
    </p> 
       <p>
      Experience:<br />
      <input type="text" name="exp" size="30" maxlength="30" value="" />
    </p>
        <p>
      SSC Reg No.:<br />
      <input type="text" name="sscreg" size="30" maxlength="30" value="" />
    </p>
    <p>
      HSC Reg No.:<br />
      <input type="text" name="hscreg" size="30" maxlength="30" value="" />
    </p>
         <p>
      Dakhil Reg No.:<br />
      <input type="text" name="dakhilreg" size="30" maxlength="30" value="" />
    </p>
      <p>
      Phone Number:<br />
      <input type="text" name="ph" size="30" maxlength="30" value="" />
    </p>
    <p>
      <input type="submit" name="submit" value="Submit!" /> 
    </p>
</form>
<a href="form.php">Back</a>
</body>



</html>