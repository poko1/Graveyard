<html>

	<head>
		<title>Search</title>
<header><h1>Employee Details</h1></header> 
	</head>
	<body>
		<form method="POST" action="">
			<input type="text" name="q" placeholder="query">
			<input type="submit" name="search" value="Search">
		</form>
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle
if(isset($_POST['search'])){

$conn = oci_connect("nourin10", "50", "localhost/xe");
$q = $_POST['q'];
$query = "select * from employee where emp_id like '%$q%' or first_name like '%$q%' or last_name like '%$q%' ";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch the results in an associative array
print '<table border="1">';
	print "<tr>\n";
	print "<th>Employee ID</th>\n";
        print "<th>NID</th>\n";
	print "<th>First Name</th>\n";
	print "<th>Last Name</th>\n";
	print "<th>Joining Date</th>\n";
	print "<th>Phone No.</th>\n";
        print "<th>Experience</th>\n";
        print "<th>SSC Reg no.</th>\n";
        print "<th>HSC Reg no.</th>\n";
       print "<th>Dakhil Reg no.</th>\n";
print "<th>Job Type</th>\n";
	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);
}


?>
</html>