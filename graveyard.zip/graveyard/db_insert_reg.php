<html>
<body>
<?php
include "reg.php";
   // If the submit button has been pressed...

   if (isset($_POST['submit']))
   {

      // Connect to the database
      $c = @oci_connect('nourin7', '50', 'localhost/xe')
                or die("Could not connect to Oracle server");
				

      // Retrieve the posted new location information.
      $emp_id = $_POST['emp_id']; 
      $nid = $_POST['nid'];
      $first_name = $_POST['first_name']; 
      $last_name = $_POST['last_name'];
      $jobtype = $_POST['jobtype'];
      $doj = $_POST['doj']; 
     $dob = $_POST['dob'];
      $exp = $_POST['exp'];
      $sscreg= $_POST['sscreg'];
      $hscreg= $_POST['hscreg'];
      $dakhilreg= $_POST['dakhilreg']; 
      $ph= $_POST['ph'];
echo 'Your bday is ' . $dob .' ' . $first_name;
      // Insert the location information into the  table
      $s = oci_parse($c, "insert into employee
                           (emp_id, nid, first_name,
                            last_name,joining_date, emp_dob,experience,ssc_reg_no,hsc_reg_no,dakhil_reg_no,job_type)
                           values ('$emp_id', '$nid', '$first_name',
                                   '$last_name', to_date('$doj','YYYY-MM-DD'),to_date('$dob','YYYY-MM-DD'),'$exp','$sscreg','$hscreg','$dakhilreg','$jobtype')");
      $result = oci_execute($s);
      
      $s = oci_parse($c, "insert into phone_number
                           (id, phone_number)
                           values ('$emp_id', '$ph')");
      $result = oci_execute($s);

      // Display an appropriate message on either success or failure
      if ($result)
      { 
         echo "<p>Location successfully inserted!</p>"; 
         oci_commit($c);
      }
      else
      { 
         echo "<p>There was a problem inserting the location!</p>";
         var_dump(oci_error($s));
      }

      oci_close($c);
    }

  // Include the insertion form
  //include "insert_location.php";
 
 

?>
</body>
</html>


