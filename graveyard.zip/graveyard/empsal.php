<html>

	<head>
		<title>Search</title>
<header><h1>Employee Salary </h1></header> 
	</head>
	<body>
	
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle


$conn = oci_connect("nourin10", "50", "localhost/xe");

$query = "select * from emp_salary_view";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);

// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
	print "<th>FIRST NAME</th>\n";
        print "<th>LAST NAME</th>\n";
	print "<th>POST</th>\n";
print "<th>SALARY</th>\n";
print "<th>REASON</th>\n";
print "<th>PAYMENT DATE</th>\n";
	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);



?>
</html>