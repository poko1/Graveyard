<html>

	<head>
		<title>Search</title>
<header><h1>Total deceased</h1></header> 
	</head>
	<body>
	
	<a href="form.php">Back</a>	 
	</body>
<?php
// Create connection to Oracle


$conn = oci_connect("nourin10", "50", "localhost/xe");

$query = "SELECT COUNT (*) 
FROM known_native UNION SELECT COUNT (*)
FROM known_foreigner  UNION SELECT COUNT (*)
FROM unknown ";
$stid = oci_parse($conn, $query);
$r = oci_execute($stid);


// Fetch the results in an associative array

print '<table border="1">';
	print "<tr>\n";
	print "<td>Foreigner </td> <td>Unknown </td> <td>Native (In that order)</td>\n";

	print "</tr>";
while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
	 
	 
   }
   print '</tr>';
}
print '</table>';


$q = "SELECT COUNT (*) 
from
(
SELECT reg_no 
FROM known_native 
union 
SELECT  reg_no 
FROM known_foreigner
union
SELECT  reg_no 
FROM unknown
)";
$s = oci_parse($conn, $q);
$r = oci_execute($s);

print '<table border="1">';
	print "<tr>\n";
	print "<th>Total deceased</th>\n";

	print "</tr>";
while ($row = oci_fetch_array($s, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
   foreach ($row as $item) {
      print '<td>'.($item?htmlentities($item):' ').'</td>';
	 
	 
   }
   print '</tr>';
}
print '</table>';



// Close the Oracle connection
oci_close($conn);



?>
</html>