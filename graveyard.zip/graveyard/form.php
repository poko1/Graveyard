<html>

<body>
<header><h1>Graveyard Database</h1></header> 
<a href="db_print.php">Employee registration</a>
<br>

<a href="query.php">Search for Employee</a>
<br>

<a href="deceased.php">Search for Deceased</a>
<br>

<a href="fund.php">Fund</a>
<br>

<a href="empsal.php">Employee Salary</a>
<br>

<a href="totalno.php">Deceased no</a>

</body>



</html>